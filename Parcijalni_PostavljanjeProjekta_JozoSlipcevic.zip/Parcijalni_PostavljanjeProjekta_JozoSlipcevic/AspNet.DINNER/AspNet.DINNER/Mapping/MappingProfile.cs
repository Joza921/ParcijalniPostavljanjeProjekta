﻿using AspNet.DINNER.Models.Dbo;
using AspNet.DINNER.Models.ViewModel;
using AutoMapper;

namespace AspNet.DINNER.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Dinner, DinnerVIewModel>();
        }
    }
}
