﻿using AspNet.DINNER.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace AspNet.DINNER.Controllers
{
    public class DinnerController : Controller
    {
        private readonly IDinner dinner;

        public DinnerController(IDinner dinner)
        {
            this.dinner = dinner;
        }
        public IActionResult Index()
        {
            var dbo = dinner.SveVecere();
            return View(dbo);
        }
    }
}
