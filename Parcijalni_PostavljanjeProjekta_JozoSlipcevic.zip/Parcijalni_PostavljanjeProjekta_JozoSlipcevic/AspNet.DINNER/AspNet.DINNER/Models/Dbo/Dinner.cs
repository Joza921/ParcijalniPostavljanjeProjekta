﻿using AspNet.DINNER.Models.Base;

namespace AspNet.DINNER.Models.Dbo
{
    public class Dinner : DinnerBase
    {
        public int id { get; set; }

    }
}
