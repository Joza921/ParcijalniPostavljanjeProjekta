﻿using AspNet.DINNER.Models.Base;

namespace AspNet.DINNER.Models.ViewModel
{
    public class DinnerVIewModel : DinnerBase
    {
        public int id { get; set; }


    }
}
