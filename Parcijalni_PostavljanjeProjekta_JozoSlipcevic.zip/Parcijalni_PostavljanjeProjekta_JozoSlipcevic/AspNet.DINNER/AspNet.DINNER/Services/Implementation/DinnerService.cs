﻿using AspNet.DINNER.Models.Dbo;
using AspNet.DINNER.Models.ViewModel;
using AspNet.DINNER.Services.Interfaces;
using AutoMapper;

namespace AspNet.DINNER.Services.Implementation
{
    public class DinnerService : IDinner
    {
        private readonly IMapper mapper;
        private List<Dinner> ListaVeceri;

        public DinnerService(IMapper mapper)
        {
            this.mapper = mapper;
            SimulacijaBaze();
            
        }

        #region Simuliranje baze
        private void SimulacijaBaze()
        {
            if (ListaVeceri == null)
            {
                ListaVeceri = new List<Dinner>();
            }
            if (ListaVeceri.Any())
            {
                return;
            }

            Dinner Dinner1 = new Dinner()
            {
                id = 1,
                Naziv = "Palačinke s lino ladom",
                Okus = "Slatko",
                PotrebanPribor = true,
                Sastojak1 = "Mlijeko",
                Sastojak2 = "Brašno",
                Sastojak3 = "Jaja"
            };
            Dinner Dinner2 = new Dinner()
            {
                id = 2,
                Naziv = "Jaja s špekom",
                Okus = "Slano",
                PotrebanPribor = true,
                Sastojak1 = "Jaja",
                Sastojak2 = "Špek",
                Sastojak3 = "Maslac"
            };
            Dinner Dinner3 = new Dinner()
            {
                id = 3,
                Naziv = "Voćna salata",
                Okus = "kiselo",
                PotrebanPribor = false,
                Sastojak1 = "Jabuka",
                Sastojak2 = "Šumsko voće",
                Sastojak3 = "lubenica"
            };
            Dinner Dinner4 = new Dinner()
            {
                id = 4,
                Naziv = "Domaća suha kobasica",
                Okus = "Fino",
                PotrebanPribor = true,
                Sastojak1 = "Suha kobasica",
                Sastojak2 = "Luk",
                Sastojak3 = "Kruh"
            };

            Dinner Dinner5 = new Dinner()
            {
                id = 5,
                Naziv = "Kroasan s mlijekom",
                Okus = "Slatko",
                PotrebanPribor = false,
                Sastojak1 = "Mlijeko",
                Sastojak2 = "Kroasan",
                Sastojak3 = "Kruh"
            };

            ListaVeceri.Add(Dinner1);
            ListaVeceri.Add(Dinner2);
            ListaVeceri.Add(Dinner3);
            ListaVeceri.Add(Dinner4);
            ListaVeceri.Add(Dinner5);

        }
        #endregion

        public List<DinnerVIewModel> SveVecere()
        {
            return ListaVeceri.Select( x => mapper.Map<DinnerVIewModel>(x) ).ToList();
        }


    }
}
