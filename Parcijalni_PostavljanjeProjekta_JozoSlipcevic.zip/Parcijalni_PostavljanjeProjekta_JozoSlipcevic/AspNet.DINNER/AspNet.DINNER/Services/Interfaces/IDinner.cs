﻿using AspNet.DINNER.Models.ViewModel;

namespace AspNet.DINNER.Services.Interfaces
{
    public interface IDinner
    {
        List<DinnerVIewModel> SveVecere();
    }
}
