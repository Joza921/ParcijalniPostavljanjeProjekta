﻿namespace $safeprojectname$.Models.Base
{
    public abstract class DinnerBase
    {
        public string Naziv { get; set; }
        public string Okus { get; set; }     
        public bool PotrebanPribor { get; set; }
        public string Sastojak1 { get; set; }
        public string Sastojak2 { get; set; }
        public string Sastojak3 { get; set; }

    }
}
