﻿using $safeprojectname$.Models.Base;

namespace $safeprojectname$.Models.ViewModel
{
    public class DinnerVIewModel : DinnerBase
    {
        public int id { get; set; }


    }
}
