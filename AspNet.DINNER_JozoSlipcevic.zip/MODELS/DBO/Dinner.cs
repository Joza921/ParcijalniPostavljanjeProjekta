﻿using $safeprojectname$.Models.Base;

namespace $safeprojectname$.Models.Dbo
{
    public class Dinner : DinnerBase
    {
        public int id { get; set; }

    }
}
