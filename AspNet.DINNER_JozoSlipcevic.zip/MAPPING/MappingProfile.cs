﻿using $safeprojectname$.Models.Dbo;
using $safeprojectname$.Models.ViewModel;
using AutoMapper;

namespace $safeprojectname$.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Dinner, DinnerVIewModel>();
        }
    }
}
