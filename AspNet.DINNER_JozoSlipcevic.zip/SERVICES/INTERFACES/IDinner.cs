﻿using $safeprojectname$.Models.ViewModel;

namespace $safeprojectname$.Services.Interfaces
{
    public interface IDinner
    {
        List<DinnerVIewModel> SveVecere();
    }
}
