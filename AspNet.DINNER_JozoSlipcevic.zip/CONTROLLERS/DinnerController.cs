﻿using $safeprojectname$.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controllers
{
    public class DinnerController : Controller
    {
        private readonly IDinner dinner;

        public DinnerController(IDinner dinner)
        {
            this.dinner = dinner;
        }
        public IActionResult Index()
        {
            var dbo = dinner.SveVecere();
            return View(dbo);
        }
    }
}
